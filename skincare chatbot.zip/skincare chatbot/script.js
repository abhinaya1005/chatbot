
const chatbox = document.getElementById('chatbox');

function sendMessage() {
    const input = document.getElementById('userInput');
    const userText = input.value;
    if (!userText.trim()) return;

    appendMessage('user', userText);
    input.value = '';

    setTimeout(() => {
        const botResponse = getBotResponse(userText);
        appendMessage('bot', botResponse);
    }, 500);
}

function appendMessage(sender, message) {
    const msg = document.createElement('div');
    msg.className = sender;
    msg.textContent = message;
    chatbox.appendChild(msg);
    chatbox.scrollTop = chatbox.scrollHeight;
}

function getBotResponse(input) {
    const lower = input.toLowerCase();

    // Simple rules
    if (lower.includes("oily skin")) {
        return "For oily skin, consider using a gentle foaming cleanser and oil-free moisturizer.";
    } else if (lower.includes("dry skin")) {
        return "Dry skin needs hydration. Look for moisturizers with hyaluronic acid or ceramides.";
    } else if (lower.includes("acne")) {
        return "Acne can be treated with products containing salicylic acid or benzoyl peroxide.";
    } else if (lower.includes("combination skin")) {
        return "use a deep clarity cleanser and gently exfoliate";
    } else if (lower.includes("recommend") || lower.includes("product")) {
        return "Can you tell me your skin type (e.g., oily, dry, combination)?";
    } else if (lower.includes("hello") || lower.includes("hi")) {
        return "Hello! Ask me anything about skincare.";
    } else if (lower.includes("thank you")) {
        return "You're welcome!";
    } else {
        return "I'm still learning. Try asking about skincare tips or issues like acne, oily skin, etc.";
    }
}
